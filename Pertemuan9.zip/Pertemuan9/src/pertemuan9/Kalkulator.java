
package pertemuan9;


public class Kalkulator implements Operasi {

    private double Bil1;
    private double Bil2;

    Kalkulator(){}
    Kalkulator (double Bil1, double Bil2){
    this.Bil1=Bil1;
    this.Bil2=Bil2;
    }
    
    
    @Override
    public void Penjumlahan() {
        double hasil = this.Bil1 + this.Bil2;
        System.out.println("Hasil: "+this.Bil1+" + "+this.Bil2+" = "+hasil);
    }

    @Override
    public void Pengurangan() {
       double hasil = this.Bil1 - this.Bil2;
        System.out.println("Hasil: "+this.Bil1+" - "+this.Bil2+" = "+hasil);
    }

    @Override
    public void Perkalian() {
        double hasil = this.Bil1 * this.Bil2;
        System.out.println("Hasil: "+this.Bil1+" * "+this.Bil2+" = "+hasil);     
    }

    @Override
    public void Pembagian() {
         double hasil = this.Bil1 / this.Bil2;
        System.out.println("Hasil: "+this.Bil1+" / "+this.Bil2+" = "+hasil);
    }
    
}
