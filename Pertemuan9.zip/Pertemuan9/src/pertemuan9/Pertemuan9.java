
package pertemuan9;
 
import java.util.Scanner;


public class Pertemuan9 {


    public static void main(String[] args) {

        Scanner sc = new Scanner (System.in);
        Kalkulator kal = new Kalkulator ();
        
        
        System.out.print("Masukan Nama bilangan ke-1 = ");
        double Bil1 = sc.nextDouble();
        System.out.print("Masukan Nama bilangan ke-2 = ");
        double Bil2 = sc.nextDouble();
        
        kal = new Kalkulator(Bil1, Bil2);
        
        
        System.out.println();
        kal.Penjumlahan();
        kal.Pengurangan();
        kal.Perkalian();
        kal.Pembagian();
        
    }
}
